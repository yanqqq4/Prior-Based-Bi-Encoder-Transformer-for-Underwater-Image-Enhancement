addpath('Method');
Image_dir = 'UCCS/INPUT';
listing = cat(1, dir(fullfile(Image_dir, '*.jpg')), dir(fullfile(Image_dir, '*.JPEG')));
% The final output will be saved in this directory:
result_dir = 'UCCS/DC';

for i_img = 1:length(listing)
    Input = imread(fullfile(Image_dir,listing(i_img).name));
    [~, img_name, img_ext] = fileparts(listing(i_img).name);
    img_name = strrep(img_name, '_input', '');     
    Out1 = LACC(Input);    
    Result = LACE(Out1);
    imwrite(Result, fullfile(result_dir, [img_name, img_ext]));
    
    % Output the image name
    disp(['Processed image: ', listing(i_img).name]);
end